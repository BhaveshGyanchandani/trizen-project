"use client";

import { useState } from "react";
import { Check, ImageOff } from "lucide-react";
import { idOf } from "@/lib/idOf";
import { Skeleton } from "@/components/ui/skeleton";

function photoUrl(photo) {
  // Always resolve through the GridFS-backed API route first — it's the
  // only storage backend a Photo can point at, and it's what enforces
  // per-photo access rules (owner/team/published-gallery). storageUrl is
  // a legacy local-disk field that doesn't survive a serverless deploy;
  // url/secure_url are kept as a last resort for any hand-shaped test data.
  const id = photo.id || photo._id;
  if (id) return `/api/photos/${id}/file`;
  if (photo.storageUrl) return photo.storageUrl;
  if (photo.url) return photo.url;
  if (photo.secure_url) return photo.secure_url;
  return null;
}

export function PhotoGridSkeleton({ count = 8 }) {
  return (
    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4">
      {Array.from({ length: count }).map((_, i) => (
        <Skeleton key={i} className="aspect-square rounded-lg" />
      ))}
    </div>
  );
}

function Thumbnail({ photo }) {
  const [failed, setFailed] = useState(false);
  const src = photoUrl(photo);

  if (!src || failed) {
    return (
      <div className="flex h-full w-full flex-col items-center justify-center gap-1.5 px-2 text-center text-muted-foreground">
        <ImageOff className="size-4" />
        <span className="text-[10px] leading-tight">Image unavailable</span>
      </div>
    );
  }

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt={photo.filename || "Event photo"}
      loading="lazy"
      onError={() => setFailed(true)}
      className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-[1.03]"
    />
  );
}

export default function PhotoGrid({
  photos,
  selectable = false,
  selectedIds,
  onToggle,
  onPhotoClick,
  locked = false,
  startIndex = 0,
  pendingIds,
  showDetails = false,
  actionLabel,
  onAction,
  actions,
  feedbackByPhoto,
}) {
  return (
    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4">
      {photos.map((photo, index) => {
        const id = idOf(photo);
        const selected = locked ? true : selectedIds?.has(id);
        const pending = pendingIds?.has(id);
        const canToggle = selectable && !locked && !pending;
        const canView = Boolean(onPhotoClick) && !pending;
        const disabled = !canToggle && !canView;
        const feedback = feedbackByPhoto?.[id] || [];

        return (
          <div
            key={id}
            className={`${locked ? "opacity-90" : ""} ${pending ? "opacity-60" : ""}`}
          >
          <figure className="group relative aspect-square overflow-hidden rounded-lg border border-border bg-muted">
            <button
              type="button"
              onClick={() => {
                if (canView) onPhotoClick(index);
                else if (canToggle) onToggle?.(id);
              }}
              className={`absolute inset-0 h-full w-full ${canView ? "cursor-zoom-in" : disabled ? "cursor-default" : ""}`}
              aria-label={
                pending
                  ? `${photo.filename} — updating`
                  : canView
                    ? `View ${photo.filename} full size`
                    : selectable
                      ? `Select ${photo.filename}`
                      : `${photo.filename} — already published`
              }
              aria-busy={pending || undefined}
              disabled={disabled}
            >
              <Thumbnail photo={photo} />
            </button>

            <span className="pointer-events-none absolute left-1.5 top-1.5 rounded bg-black/55 px-1.5 py-0.5 text-[10px] text-white">
              {String(startIndex + index + 1).padStart(3, "0")}
            </span>

            {locked && (
              <span className="pointer-events-none absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-full border border-success bg-success text-white">
                <Check className="size-3" />
              </span>
            )}

            {selectable && !locked && (
              <button
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  onToggle?.(id);
                }}
                disabled={pending}
                aria-label={`${selected ? "Unselect" : "Select"} ${photo.filename}`}
                aria-pressed={selected}
                className={`absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-wait ${
                  selected
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-white/70 bg-black/40 text-transparent"
                }`}
              >
                <Check className="size-3" />
              </button>
            )}

            {selectable && !locked && selected && (
              <span className="pointer-events-none absolute inset-0 rounded-lg border-2 border-primary" />
            )}

            {(actions || (actionLabel ? [{ label: actionLabel, onClick: onAction }] : [])).length > 0 && (
              <div className="absolute bottom-2 left-2 flex flex-wrap gap-1">
                {(actions || [{ label: actionLabel, onClick: onAction }]).map((action) => (
                  <button
                    key={action.label}
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      action.onClick?.(photo);
                    }}
                    className={`rounded-md bg-background/95 px-2 py-1 text-[11px] font-medium shadow-sm hover:bg-background ${
                      action.variant === "danger" ? "text-destructive" : "text-foreground"
                    }`}
                  >
                    {action.label}
                  </button>
                ))}
              </div>
            )}

            {locked && <span className="pointer-events-none absolute inset-0 rounded-lg border-2 border-success/70" />}
          </figure>
          {showDetails && (
            <figcaption className="px-1 pb-1 pt-2 text-xs">
              <p className="truncate font-medium" title={photo.filename}>{photo.filename || "Untitled photo"}</p>
              {photo.uploadedBy?.name && <p className="mt-0.5 truncate text-muted-foreground">Uploaded by {photo.uploadedBy.name}</p>}
              <div className="mt-1 flex items-center justify-between text-muted-foreground">
                <span>{photo.createdAt ? new Date(photo.createdAt).toLocaleString([], { dateStyle: "medium", timeStyle: "short" }) : "Upload time unavailable"}</span>
                <span className={selected ? "text-success" : ""}>{selected ? "Selected ✓" : "Unselected"}</span>
              </div>
              {feedback.length > 0 && (
                <div className="mt-2 space-y-1 border-t border-border pt-2 text-muted-foreground">
                  {feedback.map((entry) => (
                    <p key={entry.id} className="break-words">
                      <span className="font-medium text-foreground">{"★".repeat(entry.rating)}{"☆".repeat(5 - entry.rating)}</span>
                      {entry.comment ? ` — ${entry.comment}` : " — No comment"}
                    </p>
                  ))}
                </div>
              )}
            </figcaption>
          )}
          </div>
        );
      })}
    </div>
  );
}
